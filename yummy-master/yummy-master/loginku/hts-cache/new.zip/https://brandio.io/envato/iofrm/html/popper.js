<!doctype html>
<html lang="en-US" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" /><title>Page not found &#8211; Brandio</title>
<meta name='robots' content='max-image-preview:large' />
<!-- This site has installed PayPal for WooCommerce v1.4.14 - https://www.angelleye.com/product/woocommerce-paypal-plugin/ -->
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//use.typekit.net' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Brandio &raquo; Feed" href="https://brandio.io/feed/" />
<link rel="alternate" type="application/rss+xml" title="Brandio &raquo; Comments Feed" href="https://brandio.io/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/brandio.io\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.6"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://brandio.io/wp-includes/css/dist/block-library/style.min.css?ver=5.8.6' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://brandio.io/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=5.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://brandio.io/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=5.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='salient-social-css'  href='https://brandio.io/wp-content/plugins/salient-social/css/style.css?ver=1.2' type='text/css' media='all' />
<style id='salient-social-inline-css' type='text/css'>

  .sharing-default-minimal .nectar-love.loved,
  body .nectar-social[data-color-override="override"].fixed > a:before, 
  body .nectar-social[data-color-override="override"].fixed .nectar-social-inner a,
  .sharing-default-minimal .nectar-social[data-color-override="override"] .nectar-social-inner a:hover {
    background-color: #1d1934;
  }
  .nectar-social.hover .nectar-love.loved,
  .nectar-social.hover > .nectar-love-button a:hover,
  .nectar-social[data-color-override="override"].hover > div a:hover,
  #single-below-header .nectar-social[data-color-override="override"].hover > div a:hover,
  .nectar-social[data-color-override="override"].hover .share-btn:hover,
  .sharing-default-minimal .nectar-social[data-color-override="override"] .nectar-social-inner a {
    border-color: #1d1934;
  }
  #single-below-header .nectar-social.hover .nectar-love.loved i,
  #single-below-header .nectar-social.hover[data-color-override="override"] a:hover,
  #single-below-header .nectar-social.hover[data-color-override="override"] a:hover i,
  #single-below-header .nectar-social.hover .nectar-love-button a:hover i,
  .nectar-love:hover i,
  .hover .nectar-love:hover .total_loves,
  .nectar-love.loved i,
  .nectar-social.hover .nectar-love.loved .total_loves,
  .nectar-social.hover .share-btn:hover, 
  .nectar-social[data-color-override="override"].hover .nectar-social-inner a:hover,
  .nectar-social[data-color-override="override"].hover > div:hover span,
  .sharing-default-minimal .nectar-social[data-color-override="override"] .nectar-social-inner a:not(:hover) i,
  .sharing-default-minimal .nectar-social[data-color-override="override"] .nectar-social-inner a:not(:hover) {
    color: #1d1934;
  }
</style>
<link rel='stylesheet' id='theme-my-login-css'  href='https://brandio.io/wp-content/plugins/theme-my-login/assets/styles/theme-my-login.min.css?ver=7.1.3' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://brandio.io/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=5.5.4' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://brandio.io/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=5.5.4' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://brandio.io/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=5.5.4' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='font-awesome-css'  href='https://brandio.io/wp-content/themes/salient/css/font-awesome-legacy.min.css?ver=4.7.1' type='text/css' media='all' />
<link rel='stylesheet' id='salient-grid-system-css'  href='https://brandio.io/wp-content/themes/salient/css/grid-system.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='main-styles-css'  href='https://brandio.io/wp-content/themes/salient/css/style.css?ver=13.0.5' type='text/css' media='all' />
<style id='main-styles-inline-css' type='text/css'>

		#error-404{
		  text-align:center;
		  padding: 10% 0;
		  position: relative;
		  z-index: 10;
		}
		body.error {
		  padding: 0;
		}
		body #error-404[data-cc="true"] h1,
		body #error-404[data-cc="true"] h2,
		body #error-404[data-cc="true"] p {
		  color: inherit;
		}
		body.error404 .error-404-bg-img,
		body.error404 .error-404-bg-img-overlay {
		  position: absolute;
		  top: 0;
		  left: 0;
		  width: 100%;
		  height: 100%;
		  background-size: cover;
		  background-position: 50%;
		  z-index: 1;
		}
		body.error404 .error-404-bg-img-overlay {
		  opacity: 0.8;
		}
		body #error-404 h1,
		body #error-404 h2 {
		  font-family: "Open Sans";
		  font-weight:700
		}
		body #ajax-content-wrap #error-404 h1 {
		  font-size:250px;
		  line-height:250px;
		}
		body #ajax-content-wrap #error-404 h2 {
		  font-size:54px;
		}
		body #error-404 .nectar-button {
		  margin-top: 50px;
		}

		@media only screen and (max-width : 690px) {

			body .row #error-404 h1,
			body #ajax-content-wrap #error-404 h1 {
				font-size: 150px;
				line-height: 150px;
			}

			body #ajax-content-wrap #error-404 h2 {
				font-size: 32px;
			}

			body .row #error-404 {
				margin-bottom: 0;
			}
		}
		
html:not(.page-trans-loaded) { background-color: #ffffff; }
</style>
<link rel='stylesheet' id='nectar_default_font_open_sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-css'  href='https://brandio.io/wp-content/themes/salient/css/responsive.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-product-style-classic-css'  href='https://brandio.io/wp-content/themes/salient/css/third-party/woocommerce/product-style-classic.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-css'  href='https://brandio.io/wp-content/themes/salient/css/woocommerce.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='skin-original-css'  href='https://brandio.io/wp-content/themes/salient/css/skin-original.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='salient-wp-menu-dynamic-css'  href='https://brandio.io/wp-content/uploads/salient/menu-dynamic.css?ver=55235' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-widget-posts-css'  href='https://brandio.io/wp-content/themes/salient/css/elements/widget-nectar-posts.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='dynamic-css-css'  href='https://brandio.io/wp-content/themes/salient/css/salient-dynamic-styles.css?ver=79133' type='text/css' media='all' />
<style id='dynamic-css-inline-css' type='text/css'>
#header-space{background-color:#ffffff}@media only screen and (min-width:1000px){body #ajax-content-wrap.no-scroll{min-height:calc(100vh - 130px);height:calc(100vh - 130px)!important;}}@media only screen and (min-width:1000px){#page-header-wrap.fullscreen-header,#page-header-wrap.fullscreen-header #page-header-bg,html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header,.nectar_fullscreen_zoom_recent_projects,#nectar_fullscreen_rows:not(.afterLoaded) > div{height:calc(100vh - 129px);}.wpb_row.vc_row-o-full-height.top-level,.wpb_row.vc_row-o-full-height.top-level > .col.span_12{min-height:calc(100vh - 129px);}html:not(.nectar-box-roll-loaded) .nectar-box-roll > #page-header-bg.fullscreen-header{top:130px;}.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 128px)!important;}.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded),.admin-bar .nectar-slider-wrap[data-fullscreen="true"]:not(.loaded) .swiper-container{height:calc(100vh - 128px - 32px)!important;}}.post-type-archive-product.woocommerce .container-wrap,.tax-product_cat.woocommerce .container-wrap{background-color:#f6f6f6;}.woocommerce.single-product #single-meta{position:relative!important;top:0!important;margin:0;left:8px;height:auto;}.woocommerce.single-product #single-meta:after{display:block;content:" ";clear:both;height:1px;}.woocommerce ul.products li.product.material,.woocommerce-page ul.products li.product.material{background-color:#ffffff;}.woocommerce ul.products li.product.minimal .product-wrap,.woocommerce ul.products li.product.minimal .background-color-expand,.woocommerce-page ul.products li.product.minimal .product-wrap,.woocommerce-page ul.products li.product.minimal .background-color-expand{background-color:#ffffff;}.screen-reader-text,.nectar-skip-to-content:not(:focus){border:0;clip:rect(1px,1px,1px,1px);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute!important;width:1px;word-wrap:normal!important;}
</style>
<link rel='stylesheet' id='salient-child-style-css'  href='https://brandio.io/wp-content/themes/salient-child/style.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='tenon-font-css'  href='https://use.typekit.net/lik3oih.css?ver=5.8.6' type='text/css' media='all' />
<link rel='stylesheet' id='ei-style-css'  href='https://brandio.io/wp-content/plugins/marketplace-items/css/style.css?ver=5.8.6' type='text/css' media='all' />
<script type='text/javascript' src='https://brandio.io/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/brandio.io","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=5.5.4' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/js_composer_salient/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.6.0' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="https://brandio.io/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://brandio.io/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://brandio.io/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.6" />
<meta name="generator" content="WooCommerce 5.5.4" />
<script type="text/javascript"> var root = document.getElementsByTagName( "html" )[0]; root.setAttribute( "class", "js" ); </script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
		<style type="text/css" id="wp-custom-css">
			@import url('./wp-content/themes/salient-child/css/fonts/brandio.css');

*, body{
	font-family: tenon, sans-serif !important;
}
.large-text{
	font-weight: 700;
	font-size: 5rem;
	line-height: 4.9rem;
	color: #1D1934;
}
.animated-underline{
	position: relative;
	display: inline-block;
}
.animated-underline:after{
	content: "";
	position: absolute;
	bottom: 15%;
	left: 0;
	background-color: #D8FC78;
	width: 100%;
	height: 30%;
	z-index: -1;
	transform: scaleY(0);
	transform-origin: left bottom;
	animation: underline-animate .8s cubic-bezier(1.000, 0.260, 0.255, 0.865) 1s forwards;
}
.p-holder p{
	font-size: 1.2rem;
	line-height:1.8rem;
	color: #928EA8;
}
span.md{
	font-weight: 500;
}
@keyframes underline-animate{
	0%{transform: scaleY(0)}
	100%{transform: scaleY(1)}
}
::-moz-selection {
  background: #007aff;
  color: #fff;
}
::selection {
  background: #007aff;
  color: #fff;
}
.head-bg {
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center 23%;
}
.cn-button.btn-cookies {
  background: none !important;
  background-color: #fefe00 !important;
  color: #000;
  text-shadow: none;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.cn-button.btn-cookies:hover, .cn-button.btn-cookies:focus {
  color: #000;
  background-color: #fff !important;
}
.custom-b-box {
  margin: 1.5rem 0;
  padding-top: 3.5rem;
  border-radius: 17px;
  text-align: center;
  overflow: hidden;
}
.custom-b-box .title {
  color: #fff;
  font-size: 28px;
  margin-bottom: 0.5rem;
  font-family: Circular-Std-Bold, sans-serif;
  padding: 0 15px;
}
.custom-b-box .subtitle {
  color: rgba(255, 255, 255, 0.6);
  font-size: 20px;
  font-family: "Muli", sans-serif;
  font-weight: 300;
  margin-bottom: 1.3rem;
  padding: 0 15px;
}
.custom-b-box .link a {
  background-color: #fff;
  color: #1171df;
  font-family: Circular-Std-Medium, sans-serif;
  font-size: 20px;
  border-radius: 6px;
  padding: 0.8rem 1.5rem;
  display: inline-block;
  margin-bottom: 3.5rem;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  -webkit-transition: all 0.2s ease;
  transition: all 0.2s ease;
}
.custom-b-box .link a:hover, .custom-b-box .link a:focus {
  -webkit-transform: scale(1.05);
  -moz-transform: scale(1.05);
  -ms-transform: scale(1.05);
  transform: scale(1.05);
}
.custom-b-box .img {
  border-bottom-left-radius: 17px;
  border-bottom-right-radius: 17px;
  line-height: 0;
}
.custom-b-box .img img {
  margin-bottom: -8px;
  border-bottom-left-radius: 17px;
  border-bottom-right-radius: 17px;
}
.testimonial_slider .image-icon {
  font-family: Circular-Std-Medium, sans-serif !important;
  font-size: 65px;
  margin-bottom: 10px;
  color: #c1c1c1;
  border: 0;
  display: none !important;
}
.testimonial_slider .controls ul li span.pagination-switch {
  border: 0;
  background-color: #c1c1c1;
}
.testimonial_slider .controls ul li span.pagination-switch:hover, .testimonial_slider .controls ul li span.pagination-switch.active {
  background-color: #0075ff;
}
.work-info .vert-center p:first-child {
  display: none;
}
.portfolio-items[data-col-num="elastic"] .col img {
  height: auto !important;
}
.rockfm-form .uiform-main-form {
  box-shadow: none !important;
  padding: 0 !important;
}
.main-title {
  margin-bottom: 10px !important;
}
.main-title .rockfm-heading {
  font-size: 37px !important;
  color: #2b3239 !important;
  font-weight: 600 !important;
}
.main-subtitle .rockfm-heading {
  font-size: 20px !important;
  color: #3c5474 !important;
  font-weight: 300 !important;
  margin-bottom: 30px !important;
}
.protype-chk .rockfm-wrap-label {
  display: none !important;
}
.protype-chk .rockfm-label {
  font-size: 23px !important;
  font-weight: 600 !important;
  color: #556d84 !important;
}
.protype-chk .rockfm-inp2-opt-price-lbl {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 0px;
  color: #a8a8a8 !important;
}
.protype-chk .rockfm-inp2-opt-price-lbl span {
  color: #a8a8a8 !important;
}
.protype-chk .checkradios-checkbox input[type='checkbox'] {
  position: absolute !important;
  left: -9999px !important;
  visibility: hidden !important;
}
.protype-chk .sfdc-radio, .protype-chk .sfdc-checkbox {
  display: inline-block !important;
  margin: 0 !important;
  text-align: left;
  padding: 32px 20px 24px 184px;
  z-index: 1;
  width: 100%;
  max-width: 458px;
}
.protype-chk .sfdc-radio label, .protype-chk .sfdc-checkbox label {
  line-height: 22px;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.protype-chk .sfdc-radio:before, .protype-chk .sfdc-checkbox:before {
  font-family: "brandio" !important;
  font-style: normal !important;
  font-weight: normal !important;
  font-variant: normal !important;
  text-transform: none !important;
  speak: none;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  position: absolute;
  width: 152px;
  height: 100%;
  left: 2px;
  top: 2px;
  color: #fff;
  border-top-left-radius: 7px;
  border-bottom-left-radius: 7px;
  text-align: center;
  font-size: 60px;
  padding: 19px;
  pointer-events: none !important;
}
.protype-chk.protype1 div[class^="checkradios-"].checked {
  border: 2px solid #1794ff !important;
  color: #1794ff !important;
}
.protype-chk.protype1 .sfdc-radio:before, .protype-chk.protype1 .sfdc-checkbox:before {
  content: "\63";
  background-color: #1794ff;
}
.protype-chk.protype2 div[class^="checkradios-"].checked {
  border: 2px solid #7c36dd !important;
  color: #7c36dd !important;
}
.protype-chk.protype2 .sfdc-radio:before, .protype-chk.protype2 .sfdc-checkbox:before {
  content: "\61";
  background-color: #7c36dd;
}
.protype-chk.protype3 div[class^="checkradios-"].checked {
  border: 2px solid #919fb5 !important;
  color: #919fb5 !important;
}
.protype-chk.protype3 .sfdc-radio:before, .protype-chk.protype3 .sfdc-checkbox:before {
  content: "\62";
  background-color: #919fb5;
}
.protype-chk div[class^="checkradios-"] {
  border: 2px solid #e4e8ed !important;
  color: #d3d3d3 !important;
  font-size: 14px;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  border-radius: 9px !important;
  z-index: -1;
  padding: 0;
  box-shadow: 0 0 0 rgba(211, 211, 211, 0.54);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.protype-chk div[class^="checkradios-"]:before {
  position: absolute;
  content: "\f00c";
  color: rgba(255, 255, 255, 0);
  border-radius: 7px;
  font: normal normal normal 14px/1 FontAwesome;
  width: 26px;
  height: 26px;
  right: 10px;
  top: 10px;
  padding-top: 5px;
  background-color: #e4e9f0;
  box-shadow: 0 0 0 rgba(106, 215, 131, 0.0);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.protype-chk div[class^="checkradios-"].checked {
  border: 2px solid #56b1ff !important;
  color: #56b1ff !important;
  box-shadow: 0 14px 26px rgba(145, 159, 181, 0.5);
}
.protype-chk div[class^="checkradios-"].checked:before {
  color: #fff;
  background-color: #6ad784;
  box-shadow: 0 5px 8px rgba(106, 215, 131, 0.46);
}
.protype-chk .rockfm-input2-wrap .rockfm-inp2-opt-label {
  font-size: 15px !important;
  color: #3c5474 !important;
  pointer-events: none !important;
}
.protype-chk .rockfm-input2-wrap .rockfm-inp2-opt-label .subtitle {
  text-transform: uppercase;
  color: #c2c8d0;
  font-size: 11px;
  margin-top: 2px;
}
.box-normal .rockfm-label {
  font-size: 23px !important;
  font-weight: 600 !important;
  color: #556d84 !important;
}
.box-normal .rockfm-inp2-opt-price-lbl {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 0px;
  color: #a8a8a8 !important;
}
.box-normal .rockfm-inp2-opt-price-lbl span {
  color: #a8a8a8 !important;
}
.box-normal .checkradios-checkbox input[type='checkbox'] {
  position: absolute !important;
  left: -9999px !important;
  visibility: hidden !important;
}
.box-normal .sfdc-radio, .box-normal .sfdc-checkbox {
  display: inline-block !important;
  margin: 15px 10px !important;
  text-align: center;
  padding: 70px 20px 32px;
  z-index: 1;
  min-width: 196px;
}
.box-normal .sfdc-radio label, .box-normal .sfdc-checkbox label {
  line-height: 22px;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.box-normal .sfdc-radio:first-child, .box-normal .sfdc-checkbox:first-child {
  margin-left: 0 !important;
}
.box-normal .sfdc-radio:last-child, .box-normal .sfdc-checkbox:last-child {
  margin-right: 0 !important;
}
.box-normal div[class^="checkradios-"] {
  border: 2px solid #d3d3d3 !important;
  color: #d3d3d3 !important;
  font-size: 14px;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  border-radius: 16px !important;
  z-index: -1;
  padding: 0;
  box-shadow: 0 0 0 rgba(211, 211, 211, 0.54);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.box-normal div[class^="checkradios-"]:before {
  position: absolute;
  content: "\f00c";
  color: rgba(255, 255, 255, 0);
  border: 1px solid #c1c1c1;
  border-radius: 7px;
  font: normal normal normal 14px/1 FontAwesome;
  width: 26px;
  height: 26px;
  left: 50%;
  margin-left: -13px;
  top: 30px;
  padding-top: 5px;
  box-shadow: 0px 2px 4px #c1c1c1;
  background-color: #fff;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.box-normal div[class^="checkradios-"].checked {
  border: 2px solid #56b1ff !important;
  color: #56b1ff !important;
  box-shadow: 0 14px 26px rgba(86, 177, 255, 0.54);
}
.box-normal div[class^="checkradios-"].checked:before {
  color: #fff;
  border: 1px solid #56b1ff;
  background-color: #56b1ff;
  box-shadow: 0px 8px 9px rgba(86, 177, 255, 0.5);
}
.box-normal .rockfm-input2-wrap .rockfm-inp2-opt-label {
  font-size: 17px !important;
  color: #3c5474 !important;
}
.box-normal .rockfm-input2-wrap, .box-w-color .rockfm-input2-wrap {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: stretch;
  align-items: stretch;
}
.uiform-main-form .ctitle {
  display: inline-block;
  font-size: 23px !important;
  font-weight: 600 !important;
  color: #556d84 !important;
  margin-bottom: 18px;
  margin-top: 54px;
}
.uiform-main-form .ctitle-icon {
  position: relative;
  display: inline-block;
  border: 2px solid #c1c1c1;
  border-radius: 7px;
  width: 32px;
  height: 32px;
  margin-top: -0.4rem;
  vertical-align: middle;
  background-color: #fff;
  margin-right: 1.3rem;
  box-shadow: 0px 2px 12px rgba(193, 193, 193, 0.88);
}
.uiform-main-form .ctitle-icon:before {
  position: absolute;
  content: "";
  width: 35%;
  height: 2px;
  top: 11px;
  right: 6px;
  background-color: #5467c3;
}
.uiform-main-form .ctitle-icon:after {
  position: absolute;
  content: "";
  width: 85%;
  width: 58%;
  height: 2px;
  top: 16px;
  right: 6px;
  background-color: #5467c3;
}
.box-w-color .checkradios-checkbox {
  border: 0 solid #d3d3d3 !important;
  color: #d3d3d3 !important;
  font-size: 14px;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  border-radius: 16px !important;
  z-index: -1;
  padding: 0;
  box-shadow: 0 0 0 rgba(86, 177, 255, 0.54), inset 0 0 0px 2px #d3d3d3;
  overflow: hidden;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.box-w-color .checkradios-checkbox:before {
  position: absolute;
  content: "\f00c";
  color: rgba(255, 255, 255, 0);
  border: 2px solid #fff;
  border-radius: 16px;
  font: normal normal normal 14px/1 FontAwesome;
  width: 22px;
  height: 22px;
  left: 50%;
  margin-left: -11px;
  bottom: 9px;
  padding-top: 2px;
  z-index: 1;
  background-color: rgba(20, 57, 116, 0);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.box-w-color .checkradios-checkbox:after {
  position: absolute;
  content: "";
  width: 130px;
  height: 130px;
  left: 50%;
  bottom: -60px;
  border-radius: 200px;
  margin-left: -65px;
  background-color: #c1c1c1;
}
.box-w-color .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #d3d3d3;
}
.box-w-color .checkradios-checkbox.checked:before {
  background-color: rgba(20, 57, 116, 0.23);
  color: #fff;
  border: 2px solid rgba(255, 255, 255, 0);
}
.box-w-color .checkradios-checkbox input[type='checkbox'] {
  position: absolute;
  left: -9999px;
  visibility: hidden;
}
.box-w-color .rockfm-input2-wrap .rockfm-inp2-opt-label {
  position: relative;
  font-size: 14px !important;
  color: #3c5474 !important;
}
.box-w-color .rockfm-input2-wrap .rockfm-inp2-opt-label:before {
  position: absolute;
  content: "\f0e7";
  border: 1px solid #c1c1c1;
  border-radius: 7px;
  font: normal normal normal 12px/1 FontAwesome;
  width: 26px;
  height: 26px;
  left: 50%;
  margin-left: -13px;
  top: -37px;
  padding-top: 7px;
  box-shadow: 0px 2px 5px rgba(193, 193, 193, 0.66);
  background-color: #fff;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.box-w-color .rockfm-inp2-opt-price-lbl {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 35px;
  color: #fff !important;
}
.box-w-color .rockfm-inp2-opt-price-lbl span {
  color: #fff !important;
}
.box-w-color .sfdc-checkbox {
  display: inline-block !important;
  margin: 15px 14px !important;
  text-align: center;
  padding: 55px 11px 74px;
  width: 94px;
  z-index: 1;
}
.box-w-color .sfdc-checkbox:first-child {
  margin-left: 0 !important;
}
.box-w-color .sfdc-checkbox:last-child {
  margin-right: 0 !important;
}
.box-w-color .sfdc-checkbox:nth-child(1) .checkradios-checkbox:after {
  background-color: #56b1ff !important;
}
.box-w-color .sfdc-checkbox:nth-child(1) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #56b1ff !important;
}
.box-w-color .sfdc-checkbox:nth-child(1) .rockfm-inp2-opt-label:before {
  color: #56b1ff;
}
.box-w-color .sfdc-checkbox:nth-child(2) .checkradios-checkbox:after {
  background-color: #f8da33 !important;
}
.box-w-color .sfdc-checkbox:nth-child(2) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #f8da33 !important;
}
.box-w-color .sfdc-checkbox:nth-child(2) .rockfm-inp2-opt-label:before {
  color: #f8da33;
}
.box-w-color .sfdc-checkbox:nth-child(3) .checkradios-checkbox:after {
  background-color: #9e56ff !important;
}
.box-w-color .sfdc-checkbox:nth-child(3) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #9e56ff !important;
}
.box-w-color .sfdc-checkbox:nth-child(3) .rockfm-inp2-opt-label:before {
  color: #9e56ff;
}
.box-w-color .sfdc-checkbox:nth-child(4) .checkradios-checkbox:after {
  background-color: #6fe28a !important;
}
.box-w-color .sfdc-checkbox:nth-child(4) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #6fe28a !important;
}
.box-w-color .sfdc-checkbox:nth-child(4) .rockfm-inp2-opt-label:before {
  color: #6fe28a;
}
.box-w-color .sfdc-checkbox:nth-child(5) .checkradios-checkbox:after {
  background-color: #4978a7 !important;
}
.box-w-color .sfdc-checkbox:nth-child(5) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #4978a7 !important;
}
.box-w-color .sfdc-checkbox:nth-child(5) .rockfm-inp2-opt-label:before {
  color: #4978a7;
}
.box-w-color .sfdc-checkbox:nth-child(6) .checkradios-checkbox:after {
  background-color: #ff8a56 !important;
}
.box-w-color .sfdc-checkbox:nth-child(6) .checkradios-checkbox.checked {
  box-shadow: 0 16px 33px rgba(86, 177, 255, 0.46), inset 0 0 0px 2px #ff8a56 !important;
}
.box-w-color .sfdc-checkbox:nth-child(6) .rockfm-inp2-opt-label:before {
  color: #ff8a56;
}
.sfdc-wrap .sfdc-checkbox label {
  line-height: 18px;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.rockfm-slider .rockfm-label {
  font-size: 19px !important;
  color: #556d84 !important;
}
.rockfm-slider .rockfm-input4-wrap {
  position: relative;
  width: 100%;
}
.rockfm-slider .rockfm-input4-number {
  display: none !important;
}
.rockfm-slider .slider.slider-horizontal {
  width: 100% !important;
}
.rockfm-slider .minimal-form-input {
  padding: 10px !important;
  box-sizing: border-box !important;
}
.rockfm-slider .minimal-form-input > label:before, .rockfm-slider .minimal-form-input > label:after {
  display: none !important;
}
.rockfm-slider .tooltip.tooltip-main {
  opacity: 1 !important;
  margin-top: 16px !important;
  margin-left: -17px !important;
}
.rockfm-slider .tooltip.tooltip-main .tooltip-arrow {
  display: none !important;
}
.rockfm-slider .tooltip.tooltip-main .tooltip-inner {
  color: #3c5474 !important;
  background-color: transparent !important;
  font-family: Circular-Std-Medium, sans-serif;
  font-size: 14px;
}
.rockfm-slider .tooltip.tooltip-main .tooltip-inner:after {
  content: "pages";
  margin-left: 3px;
  font-family: Circular-Std-Medium, sans-serif;
  font-size: 14px;
}
.rockfm-slider .rockfm-inp4-opt-price-lbl {
  color: #a8a8a8 !important;
  margin-left: 1px !important;
  margin-top: 3px !important;
}
.rockfm-slider .rockfm-inp4-opt-price-lbl span {
  color: #a8a8a8 !important;
}
.slider-handle {
  width: 15px !important;
  height: 15px !important;
  background: none !important;
  background-color: #56b1ff !important;
  box-shadow: 0 3px 6px rgba(86, 177, 255, 0.28) !important;
  top: -1px;
}
.slider-track {
  background: none !important;
  background-color: #e6e6e6 !important;
  box-shadow: none !important;
  border-radius: 0 !important;
}
.slider-selection {
  background: none !important;
  background-color: #56b1ff !important;
  box-shadow: none !important;
  border-radius: 0 !important;
}
.slider.slider-horizontal .slider-track {
  height: 3px !important;
}
.rockfm-control-label .rockfm-label {
  font-size: 19px !important;
  color: #556d84 !important;
}
.rockfm-control-label .rockfm-sublabel {
  font-size: 16px !important;
  color: #9aa4b2 !important;
  font-style: normal !important;
  font-weight: 300 !important;
}
.rockfm-textarea .minimal-form-input {
  padding-top: 0 !important;
}
.rockfm-textarea textarea.rockfm-txtbox-inp-val {
  border: 1px solid #bfbfbf !important;
  border-radius: 7px !important;
  padding: 10px !important;
  height: 94px !important;
  box-sizing: border-box !important;
}
.rockfm-textarea .minimal-form-input > label {
  display: none !important;
}
.rockfm-input-container .minimal-form-input {
  padding-top: 0 !important;
}
.rockfm-input-container .minimal-form-input .sfdc-form-control {
  border: 1px solid #bfbfbf !important;
  border-radius: 7px !important;
  padding: 10px !important;
  box-sizing: border-box !important;
}
.rockfm-input-container .minimal-form-input > label {
  display: none !important;
}
.rockfm-form-container .rockfm-input2-wrap.rockfm-val-error {
  border: 0 !important;
}
.uiform-step-content .protype-chk + .zgpbf-gridsystem-cont {
  border: 2px solid rgba(228, 232, 237, 0) !important;
  border-radius: 14px !important;
  margin-top: 0 !important;
  opacity: 0;
  margin-bottom: 0 !important;
  -webkit-transform-origin: top center;
  -moz-transform-origin: top center;
  -ms-transform-origin: top center;
  transform-origin: top center;
  -webkit-transform: scaleY(0.6);
  -moz-transform: scaleY(0.6);
  -ms-transform: scaleY(0.6);
  transform: scaleY(0.6);
  -webkit-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}
.uiform-step-content .protype-chk + .zgpbf-gridsystem-cont:after {
  position: absolute;
  content: "";
  width: 100%;
  height: 0;
  left: 0;
  bottom: 0;
  background-color: #bccedf;
  opacity: 0;
  -webkit-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}
.uiform-step-content .protype-chk + .zgpbf-gridsystem-cont.show-el {
  border: 2px solid #e4e8ed !important;
  margin-top: 28px !important;
  margin-bottom: 56px !important;
  -webkit-transform: scaleY(1);
  -moz-transform: scaleY(1);
  -ms-transform: scaleY(1);
  transform: scaleY(1);
  opacity: 1;
}
.uiform-step-content .protype-chk + .zgpbf-gridsystem-cont.show-el:after {
  height: 2px;
  opacity: 1;
  bottom: -28px;
}
.pbox {
  padding: 20px 40px !important;
  /*
    border: 2px solid #E4E8ED;
    border-radius: 9px;
    &.pbox-top-left{
        border-right-color: rgba(228, 232, 237, 0);
        border-bottom-color: rgba(228, 232, 237, 0);
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
        margin-top: 30px !important;
    }
    &.pbox-top-right{
        border-left-color: rgba(228, 232, 237, 0);
        border-bottom-color: rgba(228, 232, 237, 0);
        border-top-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
        margin-top: 30px !important;
    }
    &.pbox-top{
        border-bottom-color: rgba(228, 232, 237, 0);
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
    }*/
  margin: 0 !important;
}
.pbox.pbox-bottom {
  background-color: #04111c;
  border-bottom-left-radius: 12px;
  border-bottom-right-radius: 12px;
}
.pbox.pbox-bottom .ctitle-icon {
  border: 0px solid #c1c1c1;
  border-radius: 9px;
  background-color: #152e43;
  box-shadow: none;
}
.pbox.pbox-bottom .ctitle-icon:before {
  top: 12px;
  background-color: #748faa;
}
.pbox.pbox-bottom .ctitle-icon:after {
  top: 17px;
  background-color: #556d84;
}
.pbox.pbox-bottom .ctitle {
  margin-top: 10px;
  margin-bottom: 10px;
  color: #556d84;
}
.pbox.pbox-bottom .csubtitle {
  color: #9aa4b2;
  font-size: 19px;
  font-weight: 400;
  font-style: normal;
  margin-left: 52px;
}
.simple-rad-list .rockfm-control-label .rockfm-label {
  font-size: 20px !important;
  color: #556d84 !important;
}
.simple-rad-list .rockfm-input2-wrap .sfdc-radio .checkradios-radio {
  border: 0px solid #337ab7 !important;
  background: #e4e9f0 !important;
  color: #fff;
  border-radius: 8px;
  padding: 7px;
  margin-right: 20px;
  -webkit-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}
.simple-rad-list .rockfm-input2-wrap .sfdc-radio .checkradios-radio:before {
  color: #fff;
}
.simple-rad-list .rockfm-input2-wrap .sfdc-radio .checkradios-radio.checked {
  background: #6ad784 !important;
  box-shadow: 0 5px 8px rgba(106, 215, 131, 0.46);
}
.simple-rad-list .rockfm-input2-wrap .sfdc-radio .rockfm-inp2-opt-label {
  font-size: 17px !important;
  color: #3c5474 !important;
}
.estimate-total .rockfm-heading {
  font-family: Circular-Std-Medium, sans-serif !important;
  font-weight: 400 !important;
  font-size: 23px !important;
  margin-top: 23px;
  margin-bottom: 30px !important;
}
.email-holder {
  margin-bottom: 30px;
}
.recapcha-holder .rockfm-wrap-label {
  display: none !important;
}
#rockfm_uilz60xy8qr .rockfm-txtbox-inp-val.sfdc-btn {
  background-color: #48d569 !important;
  border-radius: 9px !important;
  padding: 6px 17px !important;
  box-shadow: 0 8px 14px rgba(52, 191, 244, 0.31);
  margin-top: 20px;
}
.uiform-main-form .uiform-sticky-bottom-section {
  display: none !important;
  opacity: 0;
  visibility: hidden;
}
@media (max-width: 768px) {
  .pbox {
    padding: 20px 20px !important;
  }
  .box-normal .rockfm-input-container, .box-w-color .rockfm-input-container {
    position: relative;
  }
  .box-normal .rockfm-input-container:before, .box-w-color .rockfm-input-container:before, .box-normal .rockfm-input-container:after, .box-w-color .rockfm-input-container:after {
    content: "";
    position: absolute;
    top: 0;
    width: 10px;
    height: 100%;
    z-index: 10;
  }
  .box-normal .rockfm-input-container:before, .box-w-color .rockfm-input-container:before {
    left: 0;
    background-repeat: repeat-x;
    background-image: -webkit-linear-gradient(90deg, #04111c, rgba(4, 17, 28, 0));
    background-image: -o-linear-gradient(90deg, #04111c, rgba(4, 17, 28, 0));
    background-image: linear-gradient(90deg, #04111c, rgba(4, 17, 28, 0));
  }
  .box-normal .rockfm-input-container:after, .box-w-color .rockfm-input-container:after {
    right: 0;
    background-repeat: repeat-x;
    background-image: -webkit-linear-gradient(90deg, rgba(4, 17, 28, 0), #04111c);
    background-image: -o-linear-gradient(90deg, rgba(4, 17, 28, 0), #04111c);
    background-image: linear-gradient(90deg, rgba(4, 17, 28, 0), #04111c);
  }
  .box-normal .rockfm-input2-wrap, .box-w-color .rockfm-input2-wrap {
    padding-left: 10px !important;
    padding-right: 10px !important;
    overflow-y: scroll;
  }
}
#header-outer #top nav > ul > li > a {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 17px;
  color: #1b2866 !important;
}
#header-outer #top nav > ul > li > a:after {
  border-color: #3192ff;
}
.shapes-holder {
  display: inline-block;
  width: 500px;
  height: 500px;
  font-size: 0;
  line-height: 0;
}
.shapes-holder div {
  display: inline-block;
  width: 24.5%;
  height: 24.5%;
  margin-bottom: 30px;
  -webkit-transition: all 1s ease-in-out;
  transition: all 1s ease-in-out;
}
.shapes-holder div:nth-child(1), .shapes-holder div:nth-child(13) {
  background: none !important;
}
.shapes-holder div.shape1 {
  border-top-right-radius: 100%;
}
.shapes-holder div.shape2 {
  border-bottom-right-radius: 100%;
}
.shapes-holder div.shape3 {
  border-top-left-radius: 100%;
}
.shapes-holder div.shape4 {
  border-bottom-left-radius: 100%;
}
.shapes-holder div.shape5 {
  border-radius: 100%;
}
.shapes-holder div.color1 {
  background-color: #cae4ff;
}
.shapes-holder div.color2 {
  background-color: #0076ff;
}
.shapes-holder div.color3 {
  background-color: #1a2667;
}
.shapes-holder div.color4 {
  background-color: #dbf613;
}
.header-content {
  position: relative;
  text-align: center;
  padding-top: 5rem;
  padding-bottom: 10rem;
  perspective: 40px;
}
.header-content .particles {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  transition: transform 0.4s;
  pointer-events: none;
}
.header-content .particles .prt {
  position: absolute;
  display: inline-block;
  border-radius: 100%;
  width: 0;
  height: 0;
  opacity: 0;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-animation: animate-prt 1s ease 0s forwards;
  -moz-animation: animate-prt 1s ease 0s forwards;
  -ms-animation: animate-prt 1s ease 0s forwards;
  animation: animate-prt 1s ease 0s forwards;
}
.header-content .particles .prt.p1 {
  top: 7%;
  left: 6%;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  -webkit-animation-delay: 0.2s;
  -moz-animation-delay: 0.2s;
  -ms-animation-delay: 0.2s;
  animation-delay: 0.2s;
}
.header-content .particles .prt.p2 {
  top: 7%;
  left: 23%;
  -webkit-transform: scale(0.4);
  -moz-transform: scale(0.4);
  -ms-transform: scale(0.4);
  transform: scale(0.4);
  -webkit-animation-delay: 0.4s;
  -moz-animation-delay: 0.4s;
  -ms-animation-delay: 0.4s;
  animation-delay: 0.4s;
}
.header-content .particles .prt.p3 {
  bottom: 22%;
  left: 24%;
  -webkit-transform: scale(0.6);
  -moz-transform: scale(0.6);
  -ms-transform: scale(0.6);
  transform: scale(0.6);
  -webkit-animation-delay: 0.6s;
  -moz-animation-delay: 0.6s;
  -ms-animation-delay: 0.6s;
  animation-delay: 0.6s;
}
.header-content .particles .prt.p4 {
  top: 1%;
  left: 50%;
  -webkit-transform: scale(1.2);
  -moz-transform: scale(1.2);
  -ms-transform: scale(1.2);
  transform: scale(1.2);
  -webkit-animation-delay: 0.8s;
  -moz-animation-delay: 0.8s;
  -ms-animation-delay: 0.8s;
  animation-delay: 0.8s;
}
.header-content .particles .prt.p5 {
  top: 7%;
  right: 20%;
  -webkit-transform: scale(0.4);
  -moz-transform: scale(0.4);
  -ms-transform: scale(0.4);
  transform: scale(0.4);
  -webkit-animation-delay: 1s;
  -moz-animation-delay: 1s;
  -ms-animation-delay: 1s;
  animation-delay: 1s;
}
.header-content .particles .prt.p6 {
  bottom: 22%;
  right: 18%;
  -webkit-transform: scale(0.6);
  -moz-transform: scale(0.6);
  -ms-transform: scale(0.6);
  transform: scale(0.6);
  -webkit-animation-delay: 1.2s;
  -moz-animation-delay: 1.2s;
  -ms-animation-delay: 1.2s;
  animation-delay: 1.2s;
}
.header-content .particles .prt.p7 {
  bottom: 28%;
  right: 4%;
  -webkit-transform: scale(0.7);
  -moz-transform: scale(0.7);
  -ms-transform: scale(0.7);
  transform: scale(0.7);
  -webkit-animation-delay: 1.4s;
  -moz-animation-delay: 1.4s;
  -ms-animation-delay: 1.4s;
  animation-delay: 1.4s;
}
.header-content .particles .prt.p8 {
  top: 25%;
  right: -5%;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  -webkit-animation-delay: 1.6s;
  -moz-animation-delay: 1.6s;
  -ms-animation-delay: 1.6s;
  animation-delay: 1.6s;
}
.header-content .particles .prt.color1 {
  background-color: #fff1b4;
}
.header-content .particles .prt.color2 {
  background-color: #c7fffa;
}
.header-content .particles .prt.color3 {
  background-color: #86c0ff;
}
.header-content .particles .prt.color4 {
  background-color: #b4bbff;
}
.header-content .particles.front {
  transition: transform 0.6s;
}
.header-content .particles.front .prt.p1 {
  top: 32%;
  left: -6%;
  -webkit-transform: scale(2);
  -moz-transform: scale(2);
  -ms-transform: scale(2);
  transform: scale(2);
}
.header-content .particles.front .prt.p2 {
  top: 33%;
  left: 27%;
  -webkit-transform: scale(0.4);
  -moz-transform: scale(0.4);
  -ms-transform: scale(0.4);
  transform: scale(0.4);
}
.header-content .particles.front .prt.p3 {
  bottom: 16%;
  left: 45%;
  -webkit-transform: scale(1.7);
  -moz-transform: scale(1.7);
  -ms-transform: scale(1.7);
  transform: scale(1.7);
}
.header-content .particles.front .prt.p4 {
  top: 33%;
  left: initial;
  right: 27%;
  -webkit-transform: scale(0.8);
  -moz-transform: scale(0.8);
  -ms-transform: scale(0.8);
  transform: scale(0.8);
}
.header-content .particles.front .prt.p5 {
  top: 28%;
  right: 10%;
  -webkit-transform: scale(0.4);
  -moz-transform: scale(0.4);
  -ms-transform: scale(0.4);
  transform: scale(0.4);
}
.header-content .text-holder {
  transition: transform 0.5s;
  overflow: hidden;
  padding-bottom: 18px;
}
.header-content .text-holder .sm-text {
  position: relative;
  white-space: nowrap;
  overflow: hidden;
  width: 0;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 30px;
  color: #3192ff;
  background-color: #edf6ff;
  display: inline-block;
  padding: 0.5rem 0;
  margin-bottom: 0.4rem;
  transition: transform 0.5s;
  -webkit-animation: animate-sm-text 1s ease 1s forwards;
  -moz-animation: animate-sm-text 1s ease 1s forwards;
  -ms-animation: animate-sm-text 1s ease 1s forwards;
  animation: animate-sm-text 1s ease 1s forwards;
}
.header-content .text-holder .lg-text {
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 95px;
  color: #173c65;
  line-height: 85px;
  transition: transform 0.5s;
}
.header-content .text-holder .lg-text .f-line {
  overflow: hidden;
}
.header-content .text-holder .lg-text .f-line div {
  -webkit-transform: translateY(170%) rotate(7deg);
  -moz-transform: translateY(170%) rotate(7deg);
  -ms-transform: translateY(170%) rotate(7deg);
  transform: translateY(170%) rotate(7deg);
  -webkit-animation: animate-lg-text 1s ease 1.4s forwards;
  -moz-animation: animate-lg-text 1s ease 1.4s forwards;
  -ms-animation: animate-lg-text 1s ease 1.4s forwards;
  animation: animate-lg-text 1s ease 1.4s forwards;
}
.header-content .text-holder .lg-text .s-line {
  overflow: hidden;
  padding-bottom: 20px;
}
.header-content .text-holder .lg-text .s-line div {
  -webkit-transform: translateY(170%) rotate(7deg);
  -moz-transform: translateY(170%) rotate(7deg);
  -ms-transform: translateY(170%) rotate(7deg);
  transform: translateY(170%) rotate(7deg);
  -webkit-animation: animate-lg-text 1s ease 1.6s forwards;
  -moz-animation: animate-lg-text 1s ease 1.6s forwards;
  -ms-animation: animate-lg-text 1s ease 1.6s forwards;
  animation: animate-lg-text 1s ease 1.6s forwards;
}
@-webkit-keyframes animate-prt {
  0% {
    opacity: 0;
    width: 0;
    height: 0;
  }
  100% {
    opacity: 1;
    width: 60px;
    height: 60px;
  }
}
@-moz-keyframes animate-prt {
  0% {
    opacity: 0;
    width: 0;
    height: 0;
  }
  100% {
    opacity: 1;
    width: 60px;
    height: 60px;
  }
}
@-ms-keyframes animate-prt {
  0% {
    opacity: 0;
    width: 0;
    height: 0;
  }
  100% {
    opacity: 1;
    width: 60px;
    height: 60px;
  }
}
@keyframes animate-prt {
  0% {
    opacity: 0;
    width: 0;
    height: 0;
  }
  100% {
    opacity: 1;
    width: 60px;
    height: 60px;
  }
}
@-webkit-keyframes animate-sm-text {
  0% {
    width: 0;
    padding: 0.5rem 0;
  }
  100% {
    width: 280px;
    padding: 0.5rem 0.7rem;
  }
}
@-moz-keyframes animate-sm-text {
  0% {
    width: 0;
    padding: 0.5rem 0;
  }
  100% {
    width: 280px;
    padding: 0.5rem 0.7rem;
  }
}
@-ms-keyframes animate-sm-text {
  0% {
    width: 0;
    padding: 0.5rem 0;
  }
  100% {
    width: 280px;
    padding: 0.5rem 0.7rem;
  }
}
@keyframes animate-sm-text {
  0% {
    width: 0;
    padding: 0.5rem 0;
  }
  100% {
    width: 280px;
    padding: 0.5rem 0.7rem;
  }
}
@-webkit-keyframes animate-lg-text {
  0% {
    -webkit-transform: translateY(170%) rotate(7deg);
    -moz-transform: translateY(170%) rotate(7deg);
    -ms-transform: translateY(170%) rotate(7deg);
    transform: translateY(170%) rotate(7deg);
  }
  100% {
    -webkit-transform: translateY(0%) rotate(0deg);
    -moz-transform: translateY(0%) rotate(0deg);
    -ms-transform: translateY(0%) rotate(0deg);
    transform: translateY(0%) rotate(0deg);
  }
}
@-moz-keyframes animate-lg-text {
  0% {
    -webkit-transform: translateY(170%) rotate(7deg);
    -moz-transform: translateY(170%) rotate(7deg);
    -ms-transform: translateY(170%) rotate(7deg);
    transform: translateY(170%) rotate(7deg);
  }
  100% {
    -webkit-transform: translateY(0%) rotate(0deg);
    -moz-transform: translateY(0%) rotate(0deg);
    -ms-transform: translateY(0%) rotate(0deg);
    transform: translateY(0%) rotate(0deg);
  }
}
@-ms-keyframes animate-lg-text {
  0% {
    -webkit-transform: translateY(170%) rotate(7deg);
    -moz-transform: translateY(170%) rotate(7deg);
    -ms-transform: translateY(170%) rotate(7deg);
    transform: translateY(170%) rotate(7deg);
  }
  100% {
    -webkit-transform: translateY(0%) rotate(0deg);
    -moz-transform: translateY(0%) rotate(0deg);
    -ms-transform: translateY(0%) rotate(0deg);
    transform: translateY(0%) rotate(0deg);
  }
}
@keyframes animate-lg-text {
  0% {
    -webkit-transform: translateY(170%) rotate(7deg);
    -moz-transform: translateY(170%) rotate(7deg);
    -ms-transform: translateY(170%) rotate(7deg);
    transform: translateY(170%) rotate(7deg);
  }
  100% {
    -webkit-transform: translateY(0%) rotate(0deg);
    -moz-transform: translateY(0%) rotate(0deg);
    -ms-transform: translateY(0%) rotate(0deg);
    transform: translateY(0%) rotate(0deg);
  }
}
.ready-row {
  padding: 5rem 0;
  text-align: center;
}
.ready-row .title {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 28px;
  margin-bottom: 1rem;
  color: rgba(255, 255, 255, 0.57);
}
.ready-row .text {
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 40px;
  line-height: 50px;
  margin-bottom: 4rem;
  color: #fff;
}
.ready-row .br-btn {
  display: inline-block;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 20px;
  color: #fff;
  background-color: #007aff;
  border-radius: 5px;
  padding: 0.7rem 2.8rem;
  -webkit-transition: all 0.4s ease-in-out;
  transition: all 0.4s ease-in-out;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
}
.ready-row .br-btn .btn-text-holder {
  overflow: hidden;
}
.ready-row .br-btn .btn-text-holder .btn-text {
  position: relative;
  -webkit-transform: translatex(0rem);
  -moz-transform: translatex(0rem);
  -ms-transform: translatex(0rem);
  transform: translatex(0rem);
  -webkit-transition: all 0.7s ease-in-out;
  transition: all 0.7s ease-in-out;
}
.ready-row .br-btn .btn-text-holder .btn-text:after {
  position: absolute;
  content: attr(data-text);
  top: 0;
  left: 0;
  -webkit-transform: translatex(7rem);
  -moz-transform: translatex(7rem);
  -ms-transform: translatex(7rem);
  transform: translatex(7rem);
  -webkit-transition: all 0.7s ease-in-out;
  transition: all 0.7s ease-in-out;
}
.ready-row .br-btn:hover {
  -webkit-transform: scale(1.06);
  -moz-transform: scale(1.06);
  -ms-transform: scale(1.06);
  transform: scale(1.06);
}
.ready-row .br-btn:hover .btn-text-holder .btn-text {
  -webkit-transform: translatex(-7rem);
  -moz-transform: translatex(-7rem);
  -ms-transform: translatex(-7rem);
  transform: translatex(-7rem);
}
.ready-row .br-btn:hover .btn-text-holder .btn-text:after {
  -webkit-transform: translatex(7rem);
  -moz-transform: translatex(7rem);
  -ms-transform: translatex(7rem);
  transform: translatex(7rem);
}
#footer-outer .row {
  padding: 5rem 0;
}
.footer-title {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 28px;
  margin-bottom: 2rem;
  color: rgba(255, 255, 255, 0.57);
}
.footer-spacer {
  margin-bottom: 7rem;
}
#footer-outer .widget {
  margin-bottom: 0;
}
.widget #menu-footer-menu {
  position: relative;
  display: inline-block;
}
.widget #menu-footer-menu .hover-bg {
  z-index: 1;
  position: absolute;
  content: "";
  background-color: #fff;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  border-radius: 5px;
  pointer-events: none;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-transform-origin: center center;
  -moz-transform-origin: center center;
  -ms-transform-origin: center center;
  transform-origin: center center;
}
.widget #menu-footer-menu li {
  z-index: 10;
  position: relative;
  border: 0 !important;
  display: inline-block;
  margin-right: 2.2rem;
}
.widget #menu-footer-menu li:last-child {
  margin-right: 0;
}
.widget #menu-footer-menu li a {
  display: inline-block;
  position: relative;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 18px;
  border: 0;
  padding: 8px 0 !important;
  -webkit-transition: 0.3s;
  transition: 0.3s;
  -webkit-transform-origin: center center;
  -moz-transform-origin: center center;
  -ms-transform-origin: center center;
  transform-origin: center center;
}
.widget #menu-footer-menu li a:before {
  position: absolute;
  content: "";
  width: calc(100% + 30px);
  height: 100%;
  top: 0;
  left: 0;
  margin-left: -15px;
  background-color: #007aff;
  -webkit-transform: scale(0.05, 0.1);
  -moz-transform: scale(0.05, 0.1);
  -ms-transform: scale(0.05, 0.1);
  transform: scale(0.05, 0.1);
  -webkit-transform-origin: center;
  -moz-transform-origin: center;
  -ms-transform-origin: center;
  transform-origin: center;
  opacity: 0;
  border-radius: 50px;
  z-index: -1;
  -webkit-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}
.widget #menu-footer-menu li a span {
  opacity: 0.6;
}
.widget #menu-footer-menu li a .btn-text-holder {
  overflow: hidden;
}
.widget #menu-footer-menu li a .btn-text-holder .btn-text {
  position: relative;
  color: #fff;
  -webkit-transform: translatex(0rem);
  -moz-transform: translatex(0rem);
  -ms-transform: translatex(0rem);
  transform: translatex(0rem);
  -webkit-transition: all 0.6s ease-in-out;
  transition: all 0.6s ease-in-out;
}
.widget #menu-footer-menu li a .btn-text-holder .btn-text:after {
  position: absolute;
  content: attr(data-text);
  color: #0074f4;
  top: 0;
  left: 0;
  -webkit-transform: translatex(100%);
  -moz-transform: translatex(100%);
  -ms-transform: translatex(100%);
  transform: translatex(100%);
  -webkit-transition: all 0.6s ease-in-out;
  transition: all 0.6s ease-in-out;
}
.widget #menu-footer-menu li a:hover:before {
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  border-radius: 5px;
  opacity: 1;
  background-color: #fff;
}
.widget #menu-footer-menu li a:hover .btn-text-holder .btn-text {
  -webkit-transform: translatex(-100%);
  -moz-transform: translatex(-100%);
  -ms-transform: translatex(-100%);
  transform: translatex(-100%);
}
.widget #menu-footer-menu li a:hover .btn-text-holder .btn-text:after {
  -webkit-transform: translatex(100%);
  -moz-transform: translatex(100%);
  -ms-transform: translatex(100%);
  transform: translatex(100%);
}
#footer-outer #footer-widgets .col ul li:first-child > a, #footer-outer #footer-widgets .col ul li:first-child {
  padding-top: 8px !important;
}
.footer-email a {
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 40px;
}
.footer-other-text {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 18px;
}
.footer-other-text span {
  margin-left: 2rem;
}
.footer-social-links a {
  margin-right: 1rem;
  font-size: 18px;
  background-color: rgba(6, 25, 47, 0.0);
  padding: 1.5rem 2rem;
  border-radius: 6px;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.footer-social-links a:hover, .footer-social-links a:focus {
  background-color: rgba(6, 25, 47, 0.08);
}
.footer-social-links .no-link {
  margin-right: 1rem;
  font-size: 18px;
  padding: 1.5rem 2rem 1.5rem 0;
}
#footer-outer {
  /*::selection {
    background-color: #0078ff;
    color: white;
}*/
}
#footer-outer #copyright {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 18px;
  color: #fff;
  display: none;
}
.br-posts-holder {
  padding: 5.5rem 6rem;
}
.br-posts-holder .br-posts-head {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: center;
  align-items: center;
}
.br-posts-holder .br-posts-head .head-title {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
  text-align: left;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 31px;
  color: #1b2866;
}
.br-posts-holder .br-posts-head .head-link-holder {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
  text-align: right;
}
.br-posts-holder .br-posts-head .head-link-holder a {
  color: #4a77f7;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 17px;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.br-posts-holder .br-posts-head .head-link-holder a:hover {
  color: #1b2866;
}
.br-posts-holder .br-post {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: center;
  align-items: center;
  margin: 6rem 0;
}
.br-posts-holder .br-post .title-holder {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
}
.br-posts-holder .br-post .title-holder .title {
  margin-bottom: 1rem;
}
.br-posts-holder .br-post .title-holder .title a {
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 29px;
  color: #1b2866;
}
.br-posts-holder .br-post .title-holder .title .tags {
  margin-left: 1rem;
  vertical-align: middle;
  display: inline-block;
  margin-top: -0.5rem;
}
.br-posts-holder .br-post .title-holder .title .tags .tag {
  display: inline-block;
  background-color: #f4f5ff;
  color: #1b2866;
  padding: 0.2rem 0.7rem;
  line-height: 14px;
  border-radius: 1rem;
  font-size: 14px;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  margin-right: 0.5rem;
}
.br-posts-holder .br-post .title-holder .title .tags .tag:nth-child(even) {
  background-color: #fff1b4;
}
.br-posts-holder .br-post .title-holder .excerpt {
  color: #576191;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 19px;
}
.br-posts-holder .br-post .title-holder .btns {
  margin-top: 2rem;
}
.br-posts-holder .br-post .title-holder .btns .btn-download {
  display: inline-block;
  background-color: #32d571;
  color: #fff;
  margin-right: 1rem;
  font-family: Circular-Std-Black, sans-serif;
  border-radius: 7px;
  padding: 0.5rem 2rem;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.br-posts-holder .br-post .title-holder .btns .btn-download:hover, .br-posts-holder .br-post .title-holder .btns .btn-download:focus {
  background-color: #2fc268;
}
.br-posts-holder .br-post .title-holder .btns .btn-view {
  position: relative;
  display: inline-block;
  background-color: #e7ecf8;
  color: #5377a0;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  border-radius: 7px;
  padding: 0.5rem 2rem;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.br-posts-holder .br-post .title-holder .btns .btn-view:before {
  position: absolute;
  content: "";
  bottom: 6px;
  right: 3px;
  width: 0;
  height: 0;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  border-top: 6px solid #c9d1e5;
  -webkit-transform: rotate(-45deg) scale(1);
  -moz-transform: rotate(-45deg) scale(1);
  -ms-transform: rotate(-45deg) scale(1);
  transform: rotate(-45deg) scale(1);
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.br-posts-holder .br-post .title-holder .btns .btn-view:hover, .br-posts-holder .br-post .title-holder .btns .btn-view:focus {
  background-color: #dce4f7;
}
.br-posts-holder .br-post .title-holder .btns .btn-view:hover:before, .br-posts-holder .br-post .title-holder .btns .btn-view:focus:before {
  border-top: 6px solid #007aff;
  -webkit-transform: rotate(-45deg) scale(1.3);
  -moz-transform: rotate(-45deg) scale(1.3);
  -ms-transform: rotate(-45deg) scale(1.3);
  transform: rotate(-45deg) scale(1.3);
}
.br-posts-holder .br-post .img-holder {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
  padding-left: 50px;
  text-align: left;
}
.br-posts-holder .br-post .img-holder .img-box {
  position: relative;
  display: inline-block;
}
.br-posts-holder .br-post .img-holder .img-box > img {
  border-radius: 25px;
  -webkit-box-shadow: 0 25px 30px rgba(116, 116, 116, 0.15);
  box-shadow: 0 25px 30px rgba(116, 116, 116, 0.15);
  width: 100%;
  max-width: 388px;
  height: auto;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  -webkit-transition: all 0.4s ease;
  transition: all 0.4s ease;
  z-index: 1;
}
.br-posts-holder .br-post .img-holder .img-box .graphics {
  position: absolute;
  display: inline-block;
  background-color: #f4f5ff;
  width: 50px;
  height: 50px;
  left: -25px;
  top: 25px;
  border-radius: 50px;
  z-index: 2;
  -webkit-transform: translateX(0) translateY(0) scale(1);
  -moz-transform: translateX(0) translateY(0) scale(1);
  -ms-transform: translateX(0) translateY(0) scale(1);
  transform: translateX(0) translateY(0) scale(1);
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
}
.br-posts-holder .br-post .img-holder .img-box .graphics:before {
  content: '';
  position: absolute;
  width: 50%;
  height: 50%;
  background-color: #fff1b4;
  border-radius: 50px;
  left: -25%;
  top: 180%;
}
.br-posts-holder .br-post .img-holder .img-box:before {
  content: '';
  position: absolute;
  width: 110px;
  height: 110px;
  background-color: #eaf4ff;
  border-radius: 110px;
  bottom: -40px;
  right: -20px;
  z-index: -1;
  -webkit-transform: translateX(0) translateY(0) scale(1);
  -moz-transform: translateX(0) translateY(0) scale(1);
  -ms-transform: translateX(0) translateY(0) scale(1);
  transform: translateX(0) translateY(0) scale(1);
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
}
.br-posts-holder .br-post .img-holder .img-box .logo-holder {
  position: absolute;
  width: 110px;
  height: 110px;
  left: -50px;
  bottom: -30px;
  border-radius: 20px;
  text-align: center;
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
  -webkit-transition: all 0.4s ease 0.1s;
  transition: all 0.4s ease 0.1s;
  z-index: 3;
}
.br-posts-holder .br-post .img-holder .img-box .logo-holder img {
  width: 100%;
  height: auto;
  border-radius: 20px;
  -webkit-box-shadow: 0 25px 30px rgba(116, 116, 116, 0.15);
  box-shadow: 0 25px 30px rgba(116, 116, 116, 0.15);
}
.br-posts-holder .br-post .img-holder .img-box:hover > img {
  -webkit-transform: scale(1.05);
  -moz-transform: scale(1.05);
  -ms-transform: scale(1.05);
  transform: scale(1.05);
}
.br-posts-holder .br-post .img-holder .img-box:hover .logo-holder {
  -webkit-transform: scale(1.05);
  -moz-transform: scale(1.05);
  -ms-transform: scale(1.05);
  transform: scale(1.05);
}
.br-posts-holder .br-post .img-holder .img-box:hover .graphics {
  -webkit-transform: translateX(-15px) translateY(-15px) scale(1.05);
  -moz-transform: translateX(-15px) translateY(-15px) scale(1.05);
  -ms-transform: translateX(-15px) translateY(-15px) scale(1.05);
  transform: translateX(-15px) translateY(-15px) scale(1.05);
}
.br-posts-holder .br-post .img-holder .img-box:hover:before {
  -webkit-transform: translateX(15px) translateY(15px) scale(1.05);
  -moz-transform: translateX(15px) translateY(15px) scale(1.05);
  -ms-transform: translateX(15px) translateY(15px) scale(1.05);
  transform: translateX(15px) translateY(15px) scale(1.05);
}
.br-posts-holder .br-post:nth-child(odd) .title-holder {
  padding-left: 4rem;
  padding-right: 0;
}
.br-posts-holder .br-post:nth-child(even) {
  -webkit-flex-direction: row-reverse;
  flex-direction: row-reverse;
}
.br-posts-holder .br-post:nth-child(even) .title-holder {
  padding-left: 0;
  padding-right: 4rem;
}
.br-posts-holder .br-post:nth-child(even) .img-holder {
  text-align: right;
}
.br-posts-holder.dark .br-posts-head .head-title {
  color: #fff;
}
.br-posts-holder.dark .br-posts-head .head-link-holder a {
  color: #6a7b90;
}
.br-posts-holder.dark .br-posts-head .head-link-holder a:hover {
  color: #fff;
}
.br-posts-holder.dark .br-post .title-holder .title a {
  color: #006ce3;
}
.br-posts-holder.dark .br-post .title-holder .title .tags {
  display: block;
  margin-left: 0;
  margin-top: 0.5rem;
}
.br-posts-holder.dark .br-post .title-holder .title .tags .tag {
  background-color: rgba(244, 245, 255, 0.12);
  color: #8394a8;
}
.br-posts-holder.dark .br-post .title-holder .title .tags .tag:nth-child(even) {
  background-color: rgba(244, 245, 255, 0.12);
}
.br-posts-holder.dark .br-post .title-holder .excerpt {
  color: #fff;
}
.br-posts-holder.dark .br-post .img-holder {
  padding-left: 0;
}
.br-posts-holder.dark .br-post .img-holder .img-box img {
  -webkit-box-shadow: 0 25px 30px rgba(116, 116, 116, 0.08);
  box-shadow: 0 25px 30px rgba(116, 116, 116, 0.08);
}
.br-posts-holder.dark .br-post .img-holder .img-box .graphics {
  background-color: rgba(60, 76, 95, 0.23);
}
.br-posts-holder.dark .br-post .img-holder .img-box .graphics:before {
  background-color: rgba(60, 76, 95, 0.23);
}
.br-posts-holder.dark .br-post .img-holder .img-box:before {
  background-color: rgba(60, 76, 95, 0.23);
}
.br-posts-holder.dark .br-post .img-holder .img-box .logo-holder {
  display: none;
}
.stand-for {
  padding: 7rem 0;
}
.stand-for .title {
  color: #fff;
  text-align: center;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 30px;
  line-height: 40px;
  margin-bottom: 5rem;
}
.stand-for .title .with-bg {
  position: relative;
  color: #fff;
  padding: 3px 9px;
}
.stand-for .title .with-bg .bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: #1f3a58;
  z-index: -1;
}
.stand-for .title .other {
  color: #3c99ff;
}
.stand-for .features {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: center;
  align-items: center;
  padding: 5rem 0;
}
.stand-for .features .feature {
  position: relative;
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
}
.stand-for .features .feature .bg-custom {
  position: absolute;
  width: 200px;
  height: 200px;
  top: 50%;
  left: 50%;
  margin-left: -100px;
  margin-top: -100px;
}
.stand-for .features .feature .bg-custom.bg1 {
  border-top-left-radius: 100%;
}
.stand-for .features .feature .bg-custom.bg2 {
  border-radius: 100%;
}
.stand-for .features .feature .bg-custom.bg3 {
  border-bottom-right-radius: 100%;
}
.stand-for .features .feature .bg-custom.bg4 {
  border-top-left-radius: 100%;
}
.stand-for .features .feature .word {
  text-align: center;
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 47px;
  line-height: 42px;
}
.stand-for .features .feature.color1 .bg-custom {
  background-color: rgba(255, 229, 111, 0.13);
}
.stand-for .features .feature.color1 .word {
  color: #ffe46f;
}
.stand-for .features .feature.color2 .bg-custom {
  background-color: rgba(150, 160, 255, 0.1);
}
.stand-for .features .feature.color2 .word {
  color: #96a0ff;
}
.stand-for .features .feature.color3 .bg-custom {
  background-color: rgba(60, 154, 255, 0.1);
}
.stand-for .features .feature.color3 .word {
  color: #3c99ff;
}
.stand-for .features .feature.color4 .bg-custom {
  background-color: rgba(141, 255, 246, 0.1);
}
.stand-for .features .feature.color4 .word {
  color: #8dfff5;
}
.we-do {
  padding: 6rem 0;
}
.we-do .title {
  color: #d5e9ff;
  text-align: center;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 27px;
  line-height: 40px;
  margin-bottom: 5rem;
}
.we-do .title span {
  color: #006ce3;
}
.we-do .do-boxes-holder {
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: center;
  align-items: center;
}
.we-do .do-boxes-holder .box-col {
  -webkit-box-flex: 1;
  -moz-box-flex: 1;
  -webkit-flex: 1;
  -ms-flex: 1;
  flex: 1;
  text-align: center;
}
.we-do .do-boxes-holder .do-box {
  position: relative;
  display: inline-block;
  text-align: center;
  border-radius: 20px;
  padding: 3rem;
  min-width: 280px;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-transform: scale(0.95);
  -moz-transform: scale(0.95);
  -ms-transform: scale(0.95);
  transform: scale(0.95);
}
.we-do .do-boxes-holder .do-box .do-title {
  font-family: Circular-Std-Bold, sans-serif;
  font-weight: 600;
  font-size: 29px;
  color: #fff;
  margin-bottom: 3rem;
}
.we-do .do-boxes-holder .do-box ul {
  padding: 0;
  margin: 0;
  list-style: none;
}
.we-do .do-boxes-holder .do-box ul li {
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  color: #74859a;
  font-size: 23px;
  list-style: none;
}
.we-do .do-boxes-holder .do-box:before {
  content: "";
  position: absolute;
  z-index: -1;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 20px;
  background-color: #06192f;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
  -webkit-transform: scale(0);
  -moz-transform: scale(0);
  -ms-transform: scale(0);
  transform: scale(0);
}
.we-do .do-boxes-holder .do-box:hover {
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
}
.we-do .do-boxes-holder .do-box:hover:before {
  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  transform: scale(1);
}
.br-cursor {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
  pointer-events: none;
  background-color: #007aff;
  border: 2px solid rgba(0, 123, 255, 0);
  width: 20px;
  height: 20px;
  margin-left: -10px;
  margin-top: -10px;
  border-radius: 100%;
  -webkit-transition: width 0.3s ease, height 0.3s ease, margin-left 0.3s ease, margin-top 0.3s ease, opacity 0.3s ease, background-color 0.3s ease, border 0.3s ease;
  transition: width 0.3s ease, height 0.3s ease, margin-left 0.3s ease, margin-top 0.3s ease, opacity 0.3s ease, background-color 0.3s ease, border 0.3s ease;
}
.br-cursor.cursor-out {
  width: 0;
  height: 0;
  margin-left: 0;
  margin-top: 0;
  opacity: 0;
}
.br-cursor.cursor-hide {
  opacity: 0;
  width: 6px;
  height: 6px;
  margin-left: -3px;
  margin-top: -3px;
}
.br-cursor.cursor-white {
  background-color: #fff;
  width: 12px;
  height: 12px;
  margin-left: -6px;
  margin-top: -6px;
}
.br-cursor.cursor-border-white {
  border: 2px solid #fff;
  background-color: transparent;
  width: 30px;
  height: 30px;
  margin-left: -15px;
  margin-top: -15px;
}
#top-container {
  min-height: 500px;
  max-height: 600px;
}
.iframe-preview-holder {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
.iframe-preview-holder #iframe-preview {
  width: 100%;
  height: 100%;
  padding-top: 58px;
}
.iframe-preview-holder .iframe-head {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 9999;
  display: -webkit-box;
  display: -moz-box;
  display: -ms-flexbox;
  display: -webkit-flex;
  display: flex;
  -webkit-align-items: center;
  align-items: center;
  background-color: #f8fcff;
  padding: 0.6rem 1.5rem;
  height: 58px;
  -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
  border-bottom: 1px solid #e1e1e1;
}
.iframe-preview-holder .iframe-head a {
  cursor: pointer !important;
}
.iframe-preview-holder .iframe-head .col1 {
  -webkit-box-flex: 1 1 20%;
  -moz-box-flex: 1 1 20%;
  -webkit-flex: 1 1 20%;
  -ms-flex: 1 1 20%;
  flex: 1 1 20%;
  text-align: left;
}
.iframe-preview-holder .iframe-head .col1 a {
  display: inline-block;
}
.iframe-preview-holder .iframe-head .col1 .logo {
  height: 27px;
  margin-bottom: -7px;
}
.iframe-preview-holder .iframe-head .col2 {
  -webkit-box-flex: 1 1 80%;
  -moz-box-flex: 1 1 80%;
  -webkit-flex: 1 1 80%;
  -ms-flex: 1 1 80%;
  flex: 1 1 80%;
  text-align: right;
}
.iframe-preview-holder .iframe-head .col2 a.btn-buy-product {
  display: inline-block;
  background-color: #32d571;
  color: #fff;
  margin-right: 0.5rem;
  font-family: Circular-Std-Black, sans-serif;
  border-radius: 7px;
  font-size: 14px;
  line-height: 20px;
  padding: 0.4rem 1rem;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.iframe-preview-holder .iframe-head .col2 a.btn-buy-product:hover, .iframe-preview-holder .iframe-head .col2 a.btn-buy-product:focus {
  background-color: #2fc268;
}
.iframe-preview-holder .iframe-head .col2 a.btn-remove-frame {
  position: relative;
  display: inline-block;
  color: #5377a0;
  font-family: Circular-Std-Book, sans-serif;
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
  border-radius: 7px;
  padding: 0.4rem 0.5rem;
  -webkit-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
.iframe-preview-holder .iframe-head .col2 a.btn-remove-frame:before {
  content: "\f00d";
  font: normal normal normal 13px/1 FontAwesome;
  margin-right: 5px;
}
.iframe-preview-holder .iframe-head .col2 a.btn-remove-frame:hover, .iframe-preview-holder .iframe-head .col2 a.btn-remove-frame:focus {
  color: #365274;
}
#footer-outer{
	display:none;
}
.portfolio-items .work-meta {
    text-align: center;
		font-size: 1.2rem;
	margin-bottom: 3rem;
}
.portfolio-items .work-meta p{
	max-width: 30rem;
    margin: 0 auto;
	display:none;
}
.portfolio-items[data-ps="9"] .col .work-item {
    margin-bottom: 50px;
}
.portfolio-items .work-meta h4, .main-content .portfolio-items .work-meta h4{
	font-size: 40px;
	font-weight: 500;
	margin-bottom: .8rem;
}
.work-item img{
	border-radius: .7rem;
}
.portfolio-items .element:nth-child(2){
	padding-top: 6rem !important;
}
@media (max-width: 1200px) {
  .header-content .text-holder .sm-text {
    font-size: 27px;
  }
  .header-content .text-holder .lg-text {
    font-size: 85px;
    line-height: 75px;
  }
  .stand-for {
    padding: 6rem 0;
  }
  .stand-for .title {
    font-size: 27px;
    line-height: 34px;
    margin-bottom: 3rem;
  }
  .stand-for .features .feature .word {
    font-size: 32px;
    line-height: 34px;
  }
  .stand-for .features .feature .bg-custom {
    width: 150px;
    height: 150px;
    margin-left: -75px;
    margin-top: -75px;
  }
  .br-posts-holder {
    padding: 5.5rem 2rem;
  }
  .br-posts-holder .br-post .title-holder .title .tags {
    margin-left: 0;
    display: block;
    margin-top: 0;
  }
}
@media (max-width: 999px) {
  body #header-outer {
    padding: 30px 0;
  }
  .header-content .particles {
    z-index: -1;
  }
  .header-content .text-holder .sm-text {
    font-size: 25px;
  }
  .header-content .text-holder .lg-text {
    font-size: 65px;
    line-height: 60px;
  }
  .stand-for {
    padding: 6rem 0 3rem;
  }
  .stand-for .title .with-bg {
    display: inline-block;
    white-space: nowrap;
  }
  .stand-for .features {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
    padding: 3rem 0;
  }
  .stand-for .features .feature {
    -webkit-box-flex: 1 1 50%;
    -moz-box-flex: 1 1 50%;
    -webkit-flex: 1 1 50%;
    -ms-flex: 1 1 50%;
    flex: 1 1 50%;
    height: 150px;
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    -webkit-align-items: center;
    align-items: center;
    -webkit-justify-content: center;
    justify-content: center;
    margin-bottom: 3rem;
  }
  .br-posts-holder .br-post {
    display: block;
  }
  .br-posts-holder .br-post:nth-child(even) .img-holder {
    text-align: center;
  }
  .br-posts-holder .br-post:nth-child(even) .title-holder {
    padding-left: 0;
    padding-right: 0;
  }
  .br-posts-holder .br-post:nth-child(odd) .img-holder {
    text-align: center;
  }
  .br-posts-holder .br-post:nth-child(odd) .title-holder {
    padding-left: 0;
    padding-right: 0;
  }
  .br-posts-holder .br-post .img-holder {
    text-align: center;
    margin-bottom: 65px;
  }
  .br-posts-holder .br-post .title-holder {
    padding-left: 0;
    padding-right: 0;
  }
  .we-do .do-boxes-holder {
    -webkit-flex-wrap: wrap;
    flex-wrap: wrap;
  }
  .footer-email a {
    font-size: 30px;
  }
  .footer-social-links .no-link {
    padding: 0.5rem 2rem 0.5rem 0;
    display: block;
    margin-right: 0;
  }
  .footer-social-links a {
    padding: 0.5rem 2rem 0.5rem 0;
    display: block;
    margin-right: 0;
  }
  .footer-social-links a:hover, .footer-social-links a:focus {
    background-color: transparent;
  }
  .br-cursor {
    display: none !important;
  }
  body {
    cursor: initial !important;
  }
  body * {
    cursor: initial !important;
  }
}
@media (max-width: 768px) {
  .br-posts-holder .br-post .img-holder {
    padding-left: 40px;
  }
  .br-posts-holder .br-post .img-holder .img-box .logo-holder {
    width: 80px;
    height: 80px;
    left: -40px;
  }
}
@media (max-width: 690px) {
  #footer-outer #copyright {
    display: block;
  }
  .footer-other-text {
    display: none;
  }
  .footer-spacer {
    margin-bottom: 2rem;
  }
	.large-text{
		font-weight: 500;
		font-size: 4rem;
		line-height:4rem;
		color: #1D1934;
	}
	.animated-underline:after{
		bottom: 10%;
		left: 0;
		width: 100%;
		height: 15%;
	}
}

/* 2022 */
.custom-block-1{
	position: relative;
	padding: 3rem !important;
	width: 100%;
	margin-left: auto;
	margin-right: auto;
	max-width: 55em;
}
.custom-block-1:before{
	position: absolute;
	content: "";
	left: 0;
	top: 0;
	width: 100%;
	height: 100%;
	background: rgb(250,244,253);
background: linear-gradient(310deg, rgba(250,244,253,1) 0%, rgba(237,240,255,1) 100%);
	filter: blur(1rem);
}
.img-on-side-holder{
	position: relative;
}
.img-on-side{
	position: absolute !important;
	top: -9rem;
	left: -8rem;
	width: 170%;
	max-width: initial !important;
}
.custom-block-1 p{
	padding-right: 2rem;
	margin-bottom: 1rem !important;
}
.margin-top-extra{
	margin-top:2rem;
}
.custom-block-1 .nectar-button{
	padding: 0;
	color: #41335F;
	font-size: 1.1rem;
}
.custom-block-1 .vc_column-inner .wpb_wrapper .nectar-button{
	background-color: transparent !important;
}
.custom-block-1 .nectar-button:before{
	content: "";
	width: 0;
	height: 0;
	border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
  
  border-left: 8px solid #fff;
	margin-right: .8rem;
	line-height: 0;
	display:inline-block;
	vertical-align: middle;
	transform: scaleY(.8);
}		</style>
		<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head><body data-rsssl=1 class="error404 theme-salient woocommerce-no-js original wpb-js-composer js-comp-ver-6.6.0 vc_responsive" data-footer-reveal="false" data-footer-reveal-shadow="none" data-header-format="default" data-body-border="off" data-boxed-style="" data-header-breakpoint="1000" data-dropdown-style="minimal" data-cae="easeOutQuart" data-cad="700" data-megamenu-width="full-width" data-aie="zoom-out" data-ls="magnific" data-apte="standard" data-hhun="1" data-fancy-form-rcs="default" data-form-style="minimal" data-form-submit="regular" data-is="minimal" data-button-style="slightly_rounded" data-user-account-button="false" data-flex-cols="true" data-col-gap="default" data-header-inherit-rc="false" data-header-search="false" data-animated-anchors="true" data-ajax-transitions="true" data-full-width-header="false" data-slide-out-widget-area="true" data-slide-out-widget-area-style="simple" data-user-set-ocm="off" data-loading-animation="none" data-bg-header="false" data-responsive="1" data-ext-responsive="true" data-ext-padding="90" data-header-resize="0" data-header-color="custom" data-cart="false" data-remove-m-parallax="" data-remove-m-video-bgs="" data-m-animate="0" data-force-header-trans-color="light" data-smooth-scrolling="0" data-permanent-transparent="false" >
	
	<script type="text/javascript">
	 (function(window, document) {

		 if(navigator.userAgent.match(/(Android|iPod|iPhone|iPad|BlackBerry|IEMobile|Opera Mini)/)) {
			 document.body.className += " using-mobile-browser ";
		 }

		 if( !("ontouchstart" in window) ) {

			 var body = document.querySelector("body");
			 var winW = window.innerWidth;
			 var bodyW = body.clientWidth;

			 if (winW > bodyW + 4) {
				 body.setAttribute("style", "--scroll-bar-w: " + (winW - bodyW - 4) + "px");
			 } else {
				 body.setAttribute("style", "--scroll-bar-w: 0px");
			 }
		 }

	 })(window, document);
   </script><a href="#ajax-content-wrap" class="nectar-skip-to-content">Skip to main content</a><div id="ajax-loading-screen" data-disable-mobile="1" data-disable-fade-on-click="0" data-effect="standard" data-method="standard"><div class="loading-icon none"><div class="material-icon">
									 <div class="spinner">
										 <div class="right-side"><div class="bar"></div></div>
										 <div class="left-side"><div class="bar"></div></div>
									 </div>
									 <div class="spinner color-2">
										 <div class="right-side"><div class="bar"></div></div>
										 <div class="left-side"><div class="bar"></div></div>
									 </div>
								 </div></div></div>	
	<div id="header-space"  data-header-mobile-fixed='false'></div> 
	
		<div id="header-outer" data-has-menu="true" data-has-buttons="no" data-header-button_style="default" data-using-pr-menu="false" data-mobile-fixed="false" data-ptnm="false" data-lhe="animated_underline" data-user-set-bg="#ffffff" data-format="default" data-permanent-transparent="false" data-megamenu-rt="1" data-remove-fixed="1" data-header-resize="0" data-cart="false" data-transparency-option="" data-box-shadow="none" data-shrink-num="6" data-using-secondary="0" data-using-logo="1" data-logo-height="30" data-m-logo-height="40" data-padding="50" data-full-width="false" data-condense="false" >
		
<div id="search-outer" class="nectar">
	<div id="search">
		<div class="container">
			 <div id="search-box">
				 <div class="inner-wrap">
					 <div class="col span_12">
						  <form role="search" action="https://brandio.io/" method="GET">
															<input type="text" name="s"  value="Start Typing..." aria-label="Search" data-placeholder="Start Typing..." />
							
						
												</form>
					</div><!--/span_12-->
				</div><!--/inner-wrap-->
			 </div><!--/search-box-->
			 <div id="close"><a href="#"><span class="screen-reader-text">Close Search</span>
				<span class="icon-salient-x" aria-hidden="true"></span>				 </a></div>
		 </div><!--/container-->
	</div><!--/search-->
</div><!--/search-outer-->

<header id="top">
	<div class="container">
		<div class="row">
			<div class="col span_3">
								<a id="logo" href="https://brandio.io" data-supplied-ml-starting-dark="false" data-supplied-ml-starting="false" data-supplied-ml="true" >
					<img class="stnd skip-lazy default-logo" width="447" height="77" alt="Brandio" src="https://brandio.io/wp-content/uploads/2021/10/brandio-logo-full-2101-sm.png" srcset="https://brandio.io/wp-content/uploads/2021/10/brandio-logo-full-2101-sm.png 1x, https://brandio.io/wp-content/uploads/2021/10/brandio-logo-full-2101.png 2x" /><img class="mobile-only-logo skip-lazy" alt="Brandio" width="400" height="254" src="https://brandio.io/wp-content/uploads/2021/10/brandio-mark-ico-tr.png" />				</a>
							</div><!--/span_3-->

			<div class="col span_9 col_last">
																	<div class="slide-out-widget-area-toggle mobile-icon simple" data-custom-color="false" data-icon-animation="simple-transform">
						<div> <a href="#sidewidgetarea" aria-label="Navigation Menu" aria-expanded="false" class="closed">
							<span class="screen-reader-text">Menu</span><span aria-hidden="true"> <i class="lines-button x2"> <i class="lines"></i> </i> </span>
						</a></div>
					</div>
				
									<nav>
													<ul class="sf-menu">
								<li id="menu-item-9495" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-9495"><a href="https://brandio.io/brandio-works/"><span class="menu-title-text">Works</span></a></li>
<li id="menu-item-9485" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-9485"><a href="https://brandio.io/product/"><span class="menu-title-text">Products</span></a></li>
<li id="menu-item-6612" class="menu-item menu-item-type-post_type menu-item-object-page nectar-regular-menu-item menu-item-6612"><a href="https://brandio.io/contact/"><span class="menu-title-text">Contact us</span></a></li>
							</ul>
													<ul class="buttons sf-menu" data-user-set-ocm="off">

								
							</ul>
						
					</nav>

					
				</div><!--/span_9-->

				
			</div><!--/row-->
			
<div id="mobile-menu" data-mobile-fixed="false">

	<div class="inner">

		
		<div class="menu-items-wrap" data-has-secondary-text="false">

			<ul>
				<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9495"><a href="https://brandio.io/brandio-works/">Works</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9485"><a href="https://brandio.io/product/">Products</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6612"><a href="https://brandio.io/contact/">Contact us</a></li>


			</ul>

			
		</div><!--/menu-items-wrap-->

		<div class="below-menu-items-wrap">
					</div><!--/below-menu-items-wrap-->

	</div><!--/inner-->

</div><!--/mobile-menu-->
		</div><!--/container-->
	</header>		
	</div>
		<div id="ajax-content-wrap">

<div class="container-wrap">
	
		
	<div class="container main-content">
		
		<div class="row">
			
			<div class="col span_12">
				
				<div id="error-404" 
								 >
					<h1>404</h1>
					<h2>Page Not Found</h2>
					
											   <a class="nectar-button large regular-button accent-color has-icon" data-color-override="false" data-hover-color-override="false" href="https://brandio.io"><span>Back Home </span><i class="icon-button-arrow"></i></a>
										</div>
				
			</div><!--/span_12-->
			
		</div><!--/row-->
		
	</div><!--/container-->
	</div><!--/container-wrap-->

<div id="footer-outer" data-midnight="light" data-cols="2" data-custom-color="true" data-disable-copyright="true" data-matching-section-color="true" data-copyright-line="false" data-using-bg-img="false" data-bg-img-overlay="0.8" data-full-width="false" data-using-widget-area="true" data-link-hover="default">
	
		
	<div id="footer-widgets" data-has-widgets="false" data-cols="2">
		
		<div class="container">
			
						
			<div class="row">
				
								
				<div class="col span_6">
												<div class="widget">			
							</div>
											</div>
					
											
						<div class="col span_6">
																<div class="widget">			
									</div>
																
							</div>
							
												
						
													
															
							</div>
													</div><!--/container-->
					</div><!--/footer-widgets-->
					
						
</div><!--/footer-outer-->


</div> <!--/ajax-content-wrap-->
<div class="br-cursor cursor-out"></div>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<link rel='stylesheet' id='nectar-woocommerce-non-critical-css'  href='https://brandio.io/wp-content/themes/salient/css/third-party/woocommerce/woocommerce-non-critical.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-css'  href='https://brandio.io/wp-content/themes/salient/css/plugins/magnific.css?ver=8.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-ocm-core-css'  href='https://brandio.io/wp-content/themes/salient/css/off-canvas/core.css?ver=13.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='nectar-ocm-simple-css'  href='https://brandio.io/wp-content/themes/salient/css/off-canvas/simple-dropdown.css?ver=13.0.5' type='text/css' media='all' />
<script type='text/javascript' id='salient-social-js-extra'>
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"https:\/\/brandio.io\/wp-admin\/admin-ajax.php","postID":"9036","rooturl":"https:\/\/brandio.io","loveNonce":"92eed18cab"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/salient-social/js/salient-social.js?ver=1.2' id='salient-social-js'></script>
<script type='text/javascript' id='theme-my-login-js-extra'>
/* <![CDATA[ */
var themeMyLogin = {"action":"","errors":[]};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/theme-my-login/assets/scripts/theme-my-login.min.js?ver=7.1.3' id='theme-my-login-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=5.5.4' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_60fd22572a92a73f10e4a32b405d5d79","fragment_name":"wc_fragments_60fd22572a92a73f10e4a32b405d5d79","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=5.5.4' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/jquery.easing.js?ver=1.3' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/jquery.mousewheel.js?ver=3.1.13' id='jquery-mousewheel-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/priority.js?ver=13.0.5' id='nectar_priority-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/transit.js?ver=0.9.9' id='nectar-transit-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/waypoints.js?ver=4.0.2' id='nectar-waypoints-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/salient-portfolio/js/third-party/imagesLoaded.min.js?ver=4.1.4' id='imagesLoaded-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/hoverintent.js?ver=1.9' id='hoverintent-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/magnific.js?ver=7.0.1' id='magnific-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/third-party/superfish.js?ver=1.5.8' id='superfish-js'></script>
<script type='text/javascript' id='nectar-frontend-js-extra'>
/* <![CDATA[ */
var nectarLove = {"ajaxurl":"https:\/\/brandio.io\/wp-admin\/admin-ajax.php","postID":"9036","rooturl":"https:\/\/brandio.io","disqusComments":"false","loveNonce":"92eed18cab","mapApiKey":""};
var nectarOptions = {"quick_search":"false","mobile_header_format":"default","left_header_dropdown_func":"default","ajax_add_to_cart":"0","ocm_remove_ext_menu_items":"remove_images","woo_product_filter_toggle":"0","woo_sidebar_toggles":"true","woo_sticky_sidebar":"0","woo_minimal_product_hover":"default","woo_minimal_product_effect":"default","woo_related_upsell_carousel":"false","woo_product_variable_select":"default"};
var nectar_front_i18n = {"next":"Next","previous":"Previous"};
/* ]]> */
</script>
<script type='text/javascript' src='https://brandio.io/wp-content/themes/salient/js/init.js?ver=13.0.5' id='nectar-frontend-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-content/plugins/salient-core/js/third-party/touchswipe.min.js?ver=1.0' id='touchswipe-js'></script>
<script type='text/javascript' src='https://brandio.io/wp-includes/js/wp-embed.min.js?ver=5.8.6' id='wp-embed-js'></script>
<script>
        var productList = {'hostify': {'name': 'Hostify','preview': 'https://brandio.io/envato/hostify/html/','buy': 'https://themeforest.net/item/hostify-hosting-html-whmcs-template/20151243'},'iofrm': {'name': 'iofrm','preview': 'https://brandio.io/envato/iofrm/html/','buy': 'https://themeforest.net/item/iofrm-login-and-register-form-templates/22413464'},'cre8': {'name': 'CRE8','preview': 'https://brandio.io/envato/cp/cre8/html/','buy': 'https://themeforest.net/item/cre8-creative-agency-html-template/24683896'},'smashing': {'name': 'Smashing Studio','preview': 'https://brandio.io/envato/smashing/html/','buy': 'https://themeforest.net/item/smashing-studio-landing-page/19712594'},'designway': {'name': 'Designway','preview': 'https://brandio.io/envato/designway/html/','buy': 'https://themeforest.net/item/designway-design-agency-html-template/19334473'},'iosoon': {'name': 'iosoon','preview': 'https://brandio.io/envato/iosoon/html/','buy': 'https://themeforest.net/item/iosoon-stunning-coming-soon-template-vol1/22764973'},'hostrocket': {'name': 'Hostrocket','preview': 'https://brandio.io/envato/hostrocket/html/','buy': 'https://themeforest.net/item/hostrocket-html5-template/10966670'},'hostbox': {'name': 'Hostbox','preview': 'https://brandio.io/envato/hostbox/html/','buy': 'https://themeforest.net/item/hostbox-html5-landing-page-template/12120861'},'spacehost': {'name': 'Spacehost','preview': 'https://brandio.io/envato/spacehost/html/','buy': 'https://themeforest.net/item/space-host-whmcs-html-landing-page/19787437'},'hostio': {'name': 'Hostio','preview': 'https://brandio.io/envato/hostio/html/','buy': 'https://themeforest.net/item/hostio-html-whmcs-web-hosting-template/19038007'},'hostino': {'name': 'Hostino','preview': 'https://brandio.io/envato/hostino/html/','buy': 'https://themeforest.net/item/hostino-whmcs-web-hosting-template/19596521'},'hustbee': {'name': 'Hustbee','preview': 'https://brandio.io/envato/hustbee/html/','buy': 'https://themeforest.net/item/hustbee-hosting-html-whmcs-template/22259226'}}</script>
<script>
window.addEventListener('load', (event) => {
					
    /*
    var shapesHolder = document.querySelector(".shapes-holder");
    
    var shapes = ['5','5','4','1',
                  '5','4','2','4',
                  '4','1','3','5',
                  '5','5','3','1'];
    var shapescolors = ['4','1','2','3',
                        '2','4','4','2',
                        '1','2','3','4',
                        '4','3','1','1'];
    for(var i=0;i<shapesHolder.childElementCount;i++){
        document.querySelector(".shapes-holder > div:nth-child("+(i+1)+")").classList.add('shape'+shapes[i]);
        document.querySelector(".shapes-holder > div:nth-child("+(i+1)+")").classList.add('color'+shapescolors[i]);
    }
    function generateGraphic(){
        var randNum = parseInt(Math.random()*shapesHolder.childElementCount);
        document.querySelector(".shapes-holder > div:nth-child("+randNum+")").className = '';
        
        var rand1 = parseInt(Math.random()*6);
        while(rand1<1){
            rand1 = parseInt(Math.random()*6);
        }
        var rand2 = parseInt(Math.random()*5);
        while(rand2<1){
            rand2 = parseInt(Math.random()*5);
        }
        document.querySelector(".shapes-holder > div:nth-child("+randNum+")").classList.add('shape'+rand1);
        document.querySelector(".shapes-holder > div:nth-child("+randNum+")").classList.add('color'+rand2);
            
    }
    var animator = setInterval(generateGraphic, 2000);
    */
    /*
    var headerContent = document.querySelector('.header-content');
    var lgText = document.querySelector('.header-content .text-holder');
    var prts1 = document.querySelector('.header-content .particles');
    var prts2 = document.querySelector('.header-content .particles.front');
    // Mouse 
    var mouse = {
      _x: 0,
      _y: 0,
      x: 0,
      y: 0,
      updatePosition: function(event) {
        var e = event || window.event;
        this.x = e.clientX - this._x;
        this.y = (e.clientY - this._y) * -1;
      },
      setOrigin: function(e) {
        this._x = e.offsetLeft + Math.floor(e.offsetWidth/2);
        this._y = e.offsetTop + Math.floor(e.offsetHeight/2);
      },
      show: function() { return '(' + this.x + ', ' + this.y + ')'; }
    }
    
    var counter = 0;
    var updateRate = 10;
    var isTimeToUpdate = function() {
      return counter++ % updateRate === 0;
    };
    
    var update = function(event) {
      mouse.updatePosition(event);
      updateTransformStyle(
        (mouse.y / lgText.offsetHeight/2).toFixed(2),
        (mouse.x / lgText.offsetWidth/2).toFixed(2)
      );
    };
    
    var updateTransformStyle = function(x, y) {
      var style = "rotateX(" + x + "deg) rotateY(" + y + "deg) translateX(" + x*1.1 + "rem) translateY(" + y*1.1 + "rem)";
      lgText.style.transform = style;
      lgText.style.webkitTransform = style;
      lgText.style.mozTransform = style;
      lgText.style.msTransform = style;
      lgText.style.oTransform = style;
      
      style = "translateX(" + y*1.6 + "rem) translateY(" + x*1.6 + "rem)";
      prts1.style.transform = style;
      prts1.style.webkitTransform = style;
      prts1.style.mozTransform = style;
      prts1.style.msTransform = style;
      prts1.style.oTransform = style;
      
      style = "translateX(" + y*3.7 + "rem) translateY(" + x*3.7 + "rem)";
      prts2.style.transform = style;
      prts2.style.webkitTransform = style;
      prts2.style.mozTransform = style;
      prts2.style.msTransform = style;
      prts2.style.oTransform = style;
    };
    */
    /*
    var onMouseEnterHandler = function(event) {
      update(event);
      // Track the mouse position relative to the center of the object.
      mouse.setOrigin(headerContent);
    };
    var onMouseLeaveHandler = function() {
      lgText.style = "";
      prts1.style = "";
      prts2.style = "";
    };
    var onMouseMoveHandler = function(event) {
      if (isTimeToUpdate()) {
        update(event);
      }
    };
    
    headerContent.onmouseenter = onMouseEnterHandler;
    headerContent.onmouseleave = onMouseLeaveHandler;
    headerContent.onmousemove = onMouseMoveHandler;
    */
});

(function($) {
    /*
    $('#menu-footer-menu li a').addClass('footer-menu-link');
    let mm = new MagnetMouse({
        magnet: {
            element: '.footer-menu-link',
            class: 'mm-active',
            distance: 0
        },
        follow: {
            element: '.hover-bg'
        }
    });
    mm.init();
    */
	$(window).on('load',function(){
	    /*
        var controller = new ScrollMagic.Controller();
        //var timeline = new TimelineMax();
        
        $('#top-container').css('height',$(window).height()-$('#header-outer').outerHeight()-60);
        
        var tween1 = TweenMax.to("#feature-bg1", 0.5, {borderTopLeftRadius: "0%", borderBottomRightRadius: "100%"});
        var tween2 = TweenMax.to("#feature-bg2", 0.5, {borderTopLeftRadius: "0%", borderBottomLeftRadius: "0%",borderBottomRightRadius: "0%"});
        var tween3 = TweenMax.to("#feature-bg3", 0.5, {borderRadius: "100%"});
        var tween4 = TweenMax.to("#feature-bg4", 0.5, {borderTopLeftRadius: "0%", borderBottomLeftRadius: "100%"});
        
        //timeline.add(tween1).add(tween2);
        // "#stand-for"
        var animTrigger = "#stand-for-features";
        var scene1 = new ScrollMagic.Scene({triggerElement: animTrigger, duration: "100%"})
					.setTween(tween1)
					.addTo(controller);
		var scene2 = new ScrollMagic.Scene({triggerElement: animTrigger, duration: "100%"})
					.setTween(tween2)
					.addTo(controller);
		var scene3 = new ScrollMagic.Scene({triggerElement: animTrigger, duration: "100%"})
					.setTween(tween3)
					.addTo(controller);
		var scene4 = new ScrollMagic.Scene({triggerElement: animTrigger, duration: "100%"})
					.setTween(tween4)
					.addTo(controller);
		
		var tweenEl = TweenMax.to(".stand-for .title .with-bg .bg", 0.5, {width: "100%"});
		var scene5 = new ScrollMagic.Scene({triggerElement: "#stand-for", duration: "50%"})
					.setTween(tweenEl)
					.addTo(controller);
		
		var brCursor = $('.br-cursor');
		
		$(document).on('mouseover',function(e){
            brCursor.removeClass('cursor-out');
        });
        $(document).on('mouseleave',function(e){
            brCursor.addClass('cursor-out');
        });
        $(document).on('mouseenter',function(e){
            brCursor.addClass('cursor-out');
        });
        $(document).on('mousemove',function(e){
            //$('.br-cursor').attr('style','top: '+e.pageY+'px; left:'+e.pageX+'px;');
            //$('.br-cursor').attr('style','top: '+e.pageY+'px; left:'+e.pageX+'px;');
            brCursor.css("transform", "translateX("+e.clientX+"px) translateY("+e.clientY+"px)");
            
            //$('.br-cursor').attr('style', 'transform: translateX('+e.clientX+'px) translateY('+e.clientY+'px)');
        });
        
        var allLinks = $('a');
        cursorCustom(allLinks,'cursor-link');
        
        var footerMenuLink = $('.footer-menu-link');
        cursorCustom(footerMenuLink,'cursor-hide');

        var footerOuter = $('#footer-outer');
        cursorCustom(footerOuter,'cursor-white');

        var brBtnBlue = $('.br-btn-blue');
        cursorCustom(brBtnBlue,'cursor-white');
        
        var btnView = $('.btn-view');
        cursorCustom(btnView,'cursor-hide');

        function cursorCustom(obj, action){
            obj.on('mouseover',function(e){
                brCursor.addClass(action);
            });
            obj.on('mouseleave',function(e){
                brCursor.removeClass(action);
            });
            obj.on('mouseenter',function(e){
                brCursor.addClass(action);
            });
        }
        */
    });
})( jQuery );

</script>
</body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: brandio.io @ 2023-02-09 02:43:11 by W3 Total Cache
-->